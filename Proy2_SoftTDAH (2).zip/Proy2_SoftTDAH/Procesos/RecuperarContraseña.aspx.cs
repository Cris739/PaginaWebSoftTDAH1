﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Proy2_SoftTDAH.Procesos
{
    public partial class RecuperarContraseña : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnActualizar_Click(object sender, EventArgs e)
        {
            string username = txtNombre.Text;
            string email = txtCorreo.Text;
            string newPassword = GeneratePassword();

            try
            {
                // Configurar el cliente de correo electrónico
                SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
                client.EnableSsl = true;
                client.Credentials = new NetworkCredential("xcristhianx739@gmail.com", "voleitors7404");

                // Crear el mensaje de correo electrónico
                MailMessage message = new MailMessage();
                message.From = new MailAddress("tu_correo@gmail.com");
                message.To.Add(email);
                message.Subject = "Recuperación de contraseña";
                message.Body = $"Su nueva contraseña es: {newPassword}";

                // Enviar el mensaje de correo electrónico
                client.Send(message);

                Label1.Text="Se ha enviado un correo electrónico con su nueva contraseña.";
            }
            catch (Exception ex)
            {
                Label1.Text = "Ha ocurrido un error al intentar enviar el correo electrónico.";
                Label1.Text = ex.Message;
            }

            this.Close();
        }

        private void Close()
        {
            throw new NotImplementedException();
        }

        static string GeneratePassword()
        {
            // Generar una contraseña aleatoria de 8 caracteres
            string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            Random random = new Random();
            string password = new string(
                Enumerable.Repeat(chars, 8)
                          .Select(s => s[random.Next(s.Length)])
                          .ToArray());
            return password;

        }

        protected void btnVolver_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Procesos/Default.aspx");
        }

        protected void btnVolver2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Procesos/Default.aspx");
        }
    }
}